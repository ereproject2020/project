self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "db22ccb2b708e63331354c35a6f9f6c4",
    "url": "/index.html"
  },
  {
    "revision": "f6d2cdb597ffb31ea5ac",
    "url": "/static/css/3.css"
  },
  {
    "revision": "f7b14548a4f1c80d101c",
    "url": "/static/css/main.css"
  },
  {
    "revision": "f6d2cdb597ffb31ea5ac",
    "url": "/static/js/3.js"
  },
  {
    "revision": "3fc2dd6c6586748d69454ed63e5b200e",
    "url": "/static/js/3.js.LICENSE"
  },
  {
    "revision": "7822ed5e633bcb96bbc4",
    "url": "/static/js/4.js"
  },
  {
    "revision": "679037ce795a598b6eaf",
    "url": "/static/js/5.js"
  },
  {
    "revision": "fec073443be78cbe9dfc",
    "url": "/static/js/6.js"
  },
  {
    "revision": "02adbb0f394e6f8b1a33a8d618a66aea",
    "url": "/static/js/6.js.LICENSE"
  },
  {
    "revision": "f7b14548a4f1c80d101c",
    "url": "/static/js/main.js"
  },
  {
    "revision": "3a7b5186fbf75afbd151",
    "url": "/static/js/runtime-main.js"
  },
  {
    "revision": "0be38b9cca4e29579451",
    "url": "/static/js/xlsx.js"
  },
  {
    "revision": "ba6628407430c7e25d546db1a797e464",
    "url": "/static/media/magnifier.ba662840.png"
  },
  {
    "revision": "212178851effa0028f61530ae3d1ac9f",
    "url": "/static/media/musical-range.21217885.png"
  },
  {
    "revision": "a6b1cf7a01a346608dd3fe48f5a51f67",
    "url": "/static/media/reset.a6b1cf7a.svg"
  },
  {
    "revision": "ca3b7251b507a98a016a21af482278f7",
    "url": "/static/media/star-empty.ca3b7251.svg"
  },
  {
    "revision": "e502c93496b233e9598566f8a69fb623",
    "url": "/static/media/star-full.e502c934.svg"
  },
  {
    "revision": "298334ed847ac79faec7da12807aecd8",
    "url": "/static/media/star-half.298334ed.svg"
  }
]);